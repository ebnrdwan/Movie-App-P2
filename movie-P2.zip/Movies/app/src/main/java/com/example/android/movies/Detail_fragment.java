package com.example.android.movies;


import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
//https://api.themoviedb.org/3/movie/284052/videos?api_key=5f7c26a298341681f7a738b181585c63&language=en-US
//        https://api.themoviedb.org/3/movie/284052/recommendations?api_key=5f7c26a298341681f7a738b181585c63&language=en-US&page=1
//        https://api.themoviedb.org/3/movie/284052/reviews?api_key=5f7c26a298341681f7a738b181585c63&language=en-US
    //https://www.youtube.com/watch?v=EZ-zFwuR0FY
    //http://img.youtube.com/vi/EZ-zFwuR0FY/default.jpg
public class Detail_fragment extends Fragment  {

    private Bitmap theposterImage;
    private String theposter;
    private String thetitle;
    private String theoverView;
    private String thereleaseDate;
    private double therating;
    public static int id;
    public String videoKey;
    public String videoTitle;
  public static ArrayList<ItemTrailer> itemTrailerList ;
    adapterTrailer adapterTrailer;
    ListView trailersList;
    adapterReview adapterReview;
    ListView reviewList;
    ArrayList<ItemReview>itemReviewsList;




    private String api_key = "5f7c26a298341681f7a738b181585c63";

    public static String Base_Detail_url = "http://api.themoviedb.org/3/movie";
    public String full_url ;

    //


    public Detail_fragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        AndroidNetworking.initialize(getContext());
        View rootView = inflater.inflate(R.layout.detail_fragment, container, false);

        Intent getdata = getActivity().getIntent();
        if (getdata != null && getdata.hasExtra("ItemObject")) {
            ItemsClass parelableItem = getdata.getParcelableExtra("ItemObject");
            thetitle = parelableItem.getTitle();
            theoverView = parelableItem.getOverview();
            thereleaseDate = parelableItem.getReleaseDate();
            therating = parelableItem.getrating() / 2;
            theposter = parelableItem.getPoster();
            id = parelableItem.getId();
        }

        //// TODO: 21/11/2016 list the reviews
        AndroidNetworking.get("https://api.themoviedb.org/3/movie/" + Integer.toString(id) + "/reviews?api_key=5f7c26a298341681f7a738b181585c63").build().getAsJSONObject(new JSONObjectRequestListener() {
            @Override
            public void onResponse(JSONObject response) {
                itemReviewsList = new ArrayList<>();
                adapterReview = new adapterReview(getContext(),itemReviewsList);
                itemReviewsList=  ParseReview(response);
                adapterReview.notifyDataSetChanged();
                reviewList.setAdapter(adapterReview);



                Toast.makeText(getContext(), "successfully load the reviews"+itemReviewsList.size(), Toast.LENGTH_LONG).show();

            }

            @Override
            public void onError(ANError anError) {

                Toast.makeText(getContext(), "can't load the reviews", Toast.LENGTH_LONG).show();
            }
        });




         //// TODO: 21/11/2016 Get Trailers
        AndroidNetworking.get("https://api.themoviedb.org/3/movie/" + Integer.toString(id) + "/videos?api_key=5f7c26a298341681f7a738b181585c63").build().getAsJSONObject(new JSONObjectRequestListener() {

            @Override
            public void onResponse(JSONObject response) {
                itemTrailerList = new ArrayList<ItemTrailer>();
                adapterTrailer = new adapterTrailer(getContext(), itemTrailerList);
                itemTrailerList = ParseVideos(response);
                itemTrailerList.size();
                adapterTrailer.notifyDataSetChanged();
                trailersList.setAdapter(adapterTrailer);
                Toast.makeText(getContext(), "successfully Fetched the video data"+ itemTrailerList.size(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(ANError anError) {
                Log.d("ERER", "can't load the trailer");
                Toast.makeText(getContext(), "can't load the trailer", Toast.LENGTH_SHORT).show();
            }
        });
        ImageView poster = (ImageView) rootView.findViewById(R.id.posterdetail);
      Picasso.with(getContext()).load(theposter).into(poster);
        TextView title = (TextView) rootView.findViewById(R.id.movietitle);
        title.setText(thetitle);
        TextView releaseDate = (TextView) rootView.findViewById(R.id.releaseDate);
        releaseDate.setText(thereleaseDate);
        RatingBar ratingbar = (RatingBar) rootView.findViewById(R.id.ratingmovie);
        ratingbar.setRating((float) therating);
        TextView overivew = (TextView) rootView.findViewById(R.id.overivewmovie);
        overivew.setText(theoverView);


        reviewList = (ListView) rootView.findViewById(R.id.reviewList);


        trailersList = (ListView) rootView.findViewById(R.id.movieList);

        trailersList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                ItemTrailer current = (ItemTrailer) adapterTrailer.getItem(i);
                String key = current.getKey();
                String videoUrl = "https://www.youtube.com/watch?v="+key;
                Intent videoIntent = new Intent(Intent.ACTION_VIEW);
                videoIntent.setData(Uri.parse(videoUrl));
                getContext().startActivity(videoIntent);
            }
        });


        return rootView;
    }

    public ArrayList<ItemTrailer> ParseVideos(JSONObject object) {

        try {
            JSONArray results = object.getJSONArray("results");
            for (int i = 0; i < results.length(); i++) {
                JSONObject vidoes = results.getJSONObject(i);
                if (vidoes.has("name") || vidoes.has("key")) {
                    String title = vidoes.getString("name");
                    String key = vidoes.getString("key");
                    videoKey = key;
                    videoTitle = title;
                }

                itemTrailerList.add(new ItemTrailer(videoTitle, videoKey));


            }
            Toast.makeText(getContext(), "Successfully parsed Video Data" + itemTrailerList.size(), Toast.LENGTH_SHORT).show();

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "can't parse the video data", Toast.LENGTH_SHORT).show();

        } finally {

            return itemTrailerList;

        }

    }

    public ArrayList<ItemReview> ParseReview(JSONObject object) {

        try {
            JSONArray results = object.getJSONArray("results");
            for (int i = 0; i < results.length(); i++) {
                JSONObject  reviews = results.getJSONObject(i);
                String author = reviews.getString("author");
                String reviewTexts = reviews.getString("content");
                itemReviewsList.add(new ItemReview(author, reviewTexts));
            }


        } catch (JSONException e) {
            e.printStackTrace();

        }
finally {
            return itemReviewsList;
        }

    }


}
