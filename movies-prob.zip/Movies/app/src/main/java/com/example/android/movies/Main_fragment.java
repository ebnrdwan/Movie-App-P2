package com.example.android.movies;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class Main_fragment extends Fragment implements LoaderManager.LoaderCallbacks<List<ItemsClass>>, SharedPreferences.OnSharedPreferenceChangeListener {


    //    public static final String BASE_MOVIE_URL = "http://api.themoviedb.org/3/movie/popular?api_key=5f7c26a298341681f7a738b181585c63";
    public static final String BASE_MOVIE_URL = "http://api.themoviedb.org/3/movie/";
    adapterMovie adapter;
    View progressBar;
    TextView emptyText;
    GridView movieGrid;
    int LOADER_ID = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.main_fragment, container, false);
        SharedPreferences mypreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        mypreferences.registerOnSharedPreferenceChangeListener(this);

        progressBar = rootview.findViewById(R.id.loadingBar);
        emptyText = (TextView) rootview.findViewById(R.id.emptytext);

        if (isConnected()) {
            movieGrid = (GridView) rootview.findViewById(R.id.gridview);
            adapter = new adapterMovie(getActivity(), new ArrayList<ItemsClass>());
            movieGrid.setAdapter(adapter);
            movieGrid.setEmptyView(emptyText);

            movieGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    ItemsClass currentItem = (ItemsClass) adapter.getItem(i);
                    Log.d("DEDE", currentItem.toString());
                    Intent gridIntent = new Intent(getActivity(), DetailActivity.class)
                            .putExtra("ItemObject", currentItem);
                    startActivity(gridIntent);
                }
            });
        } else {
            emptyText.setText("please check your network");
            progressBar.setVisibility(View.GONE);
        }

        LoaderManager loaderManager = getLoaderManager();
        Log.d("DEBUG", " the  InitLoader  method is called");
        loaderManager.initLoader(LOADER_ID, null, this);


        return rootview;

    }


    @Override
    public android.support.v4.content.Loader<List<ItemsClass>> onCreateLoader(int i, Bundle bundle) {
//       Uri movieRequest = Uri.parse(BASE_MOVIE_URL).buildUpon()
//        http://api.themoviedb.org/3/movie/popular?&sort_by=popularity&api_key=5f7c26a298341681f7a738b181585c63
        //https://api.themoviedb.org/3/movie/284052/videos?api_key=5f7c26a298341681f7a738b181585c63&language=en-US
//        https://api.themoviedb.org/3/movie/284052/recommendations?api_key=5f7c26a298341681f7a738b181585c63&language=en-US&page=1
//        https://api.themoviedb.org/3/movie/284052/reviews?api_key=5f7c26a298341681f7a738b181585c63&language=en-US
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String sortBy = preferences.getString(getString(R.string.sort_key), getString(R.string.defaultSort));

        Uri urlRequest = Uri.parse(BASE_MOVIE_URL);
        Uri.Builder uriBuilder = urlRequest.buildUpon();
        uriBuilder.appendPath(sortBy);
        uriBuilder.appendQueryParameter("api_key", "5f7c26a298341681f7a738b181585c63");
        return new LoaderMovie(getActivity(), uriBuilder.toString());
    }

    @Override
    public void onLoadFinished(Loader<List<ItemsClass>> loader, List<ItemsClass> itemsClasses) {

        if (adapter!= null) {

            if (!adapter.isEmpty()) {
                adapter.clear();
            }

            if (itemsClasses != null && !itemsClasses.isEmpty()) {
                progressBar.setVisibility(View.GONE);
                adapter.addAll(itemsClasses);
            } else {

                emptyText.setText("no matches found");
            }
        }

    }

    @Override
    public void onLoaderReset(Loader<List<ItemsClass>> loader) {
        if (adapter!= null){
            adapter.clear();
        }

    }

    public boolean isConnected() {

        ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        } else {
            return false;
        }


    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

        if (isAdded()){
            if (key.equals(getString(R.string.sort_key))) {
                if (adapter!= null)
                adapter.clear();
                emptyText.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
                getLoaderManager().restartLoader(LOADER_ID, null, this);
            } else {
                progressBar.setVisibility(View.GONE);
                emptyText.setVisibility(View.VISIBLE);
                emptyText.setText("not a proper preference ");
            }

        }


    }



}
