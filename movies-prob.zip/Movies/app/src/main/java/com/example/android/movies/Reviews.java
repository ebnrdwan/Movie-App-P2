package com.example.android.movies;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class Reviews extends Fragment {

    adapterReview adapterReview;
    int id = Detail_fragment.id;
    ArrayList<ItemReview> reviewArrayList ;
    String reviewUrl = "https://api.themoviedb.org/3/movie/" + Integer.toString(id) + "/reviews?api_key=5f7c26a298341681f7a738b181585c63&language=en-US";


    public Reviews() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
         reviewArrayList = new ArrayList<ItemReview>();
        // Inflate the layout for this fragment
        AndroidNetworking.initialize(getContext());
        View rootView = inflater.inflate(R.layout.fragment_reviews, container, false);


        List<ItemReview> itemReviews = new ArrayList<ItemReview>();
        adapterReview = new adapterReview(getContext(), itemReviews);
        adapterReview.addAll(reviewArrayList);
        ListView reviewsList = (ListView) rootView.findViewById(R.id.reviewFragmentList);
        reviewsList.setAdapter(adapterReview);



        return rootView;
    }

    public ArrayList<ItemReview> ParseReview(JSONObject object) {
        ArrayList reviewList = new ArrayList<>();
        try {
            JSONArray results = object.getJSONArray("results");
            for (int i = 0; i < results.length(); i++) {
                JSONObject reviews;
                reviews = results.getJSONObject(i);
                String author = reviews.getString("author");
                String reviewTexts = reviews.getString("content");
                reviewList.add(new ItemReview(author, reviewTexts));


            }

            return reviewList;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }


    }




    public ArrayList<ItemReview> fetchData (String reviewUrl){


        AndroidNetworking.get(reviewUrl).build().getAsJSONObject(new JSONObjectRequestListener() {
            @Override
            public void onResponse(JSONObject response) {

            reviewArrayList= ParseReview(response);


                reviewArrayList.size();

            }

            @Override
            public void onError(ANError anError) {

                Toast.makeText(getContext(), "can't load the reviews", Toast.LENGTH_LONG).show();
            }
        });

        return  reviewArrayList;

    }
}