package com.example.android.movies;


import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
//https://api.themoviedb.org/3/movie/284052/videos?api_key=5f7c26a298341681f7a738b181585c63&language=en-US
//        https://api.themoviedb.org/3/movie/284052/recommendations?api_key=5f7c26a298341681f7a738b181585c63&language=en-US&page=1
//        https://api.themoviedb.org/3/movie/284052/reviews?api_key=5f7c26a298341681f7a738b181585c63&language=en-US
    //https://www.youtube.com/watch?v=EZ-zFwuR0FY
    //http://img.youtube.com/vi/EZ-zFwuR0FY/default.jpg
public class Detail_fragment extends Fragment  {

    private Bitmap theposterImage;
    private String theposter;
    private String thetitle;
    private String theoverView;
    private String thereleaseDate;
    private double therating;
    public static int id;
    public String videoKey;
    public String videoTitle;
  public static ArrayList<ItemTrailer> itemTrailerList ;
    adapterTrailer adapterTrailer;
    ListView trailersList;




    private String api_key = "5f7c26a298341681f7a738b181585c63";

    public static String Base_Detail_url = "http://api.themoviedb.org/3/movie";
    public String full_url ;

    //


    public Detail_fragment() {

    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        Reviews reviews = new Reviews();

        FragmentManager fragmentManager = getChildFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction().add(R.id.reviewView,new Reviews());
        transaction.commit();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        AndroidNetworking.initialize(getContext());
        View rootView = inflater.inflate(R.layout.detail_fragment, container, false);

        Intent getdata = getActivity().getIntent();
        if (getdata != null && getdata.hasExtra("ItemObject")) {

//
//            List<ItemReview> itemReviews = new ArrayList<ItemReview>();
//            adapterReview adapterReview = new adapterReview(getActivity(),itemReviews);
//            adapterReview.addAll(itemReviews);
//            ListView reviewsList = (ListView) rootView.findViewById(R.id.reviewList);
//            reviewsList.setAdapter(adapterReview);


            ItemsClass parelableItem = getdata.getParcelableExtra("ItemObject");
            thetitle = parelableItem.getTitle();
            theoverView = parelableItem.getOverview();
            thereleaseDate = parelableItem.getReleaseDate();
            therating = parelableItem.getrating() / 2;
            theposter = parelableItem.getPoster();
            id = parelableItem.getId();
        }





        AndroidNetworking.get("https://api.themoviedb.org/3/movie/" + Integer.toString(id) + "/videos?api_key=5f7c26a298341681f7a738b181585c63").build().getAsJSONObject(new JSONObjectRequestListener() {

            @Override
            public void onResponse(JSONObject response) {
                itemTrailerList = new ArrayList<ItemTrailer>();
                adapterTrailer = new adapterTrailer(getContext(), itemTrailerList);
                itemTrailerList = ParseVideos(response);
                itemTrailerList.size();




                Toast.makeText(getContext(), "successfully Fetched the video data"+ itemTrailerList.size(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(ANError anError) {
                Log.d("ERER", "can't load the trailer");
                Toast.makeText(getContext(), "can't load the trailer", Toast.LENGTH_SHORT).show();
            }
        });


        ImageView poster = (ImageView) rootView.findViewById(R.id.posterdetail);
        Picasso.with(getContext()).load(theposter).into(poster);
        TextView title = (TextView) rootView.findViewById(R.id.movietitle);
        title.setText(thetitle);
        TextView releaseDate = (TextView) rootView.findViewById(R.id.releaseDate);
        releaseDate.setText(thereleaseDate);
        RatingBar ratingbar = (RatingBar) rootView.findViewById(R.id.ratingmovie);
        ratingbar.setRating((float) therating);
        TextView overivew = (TextView) rootView.findViewById(R.id.overivewmovie);
        overivew.setText(theoverView);


//
//        https://api.themoviedb.org/3/movie/284052/reviews?api_key=5f7c26a298341681f7a738b181585c63


//        int i = itemTrailerList.size();
//        Toast.makeText(getContext(),"the current list size for holder is "+i , Toast.LENGTH_SHORT).show();

        trailersList = (ListView) rootView.findViewById(R.id.reviewList);


        return rootView;
    }

    public ArrayList<ItemTrailer> ParseVideos(JSONObject object) {

        try {
            JSONArray results = object.getJSONArray("results");
            for (int i = 0; i < results.length(); i++) {
                JSONObject vidoes = results.getJSONObject(i);
                if (vidoes.has("name") || vidoes.has("key")) {
                    String title = vidoes.getString("name");
                    String key = vidoes.getString("key");
                    videoKey = key;
                    videoTitle = title;
                }

                itemTrailerList.add(new ItemTrailer(videoTitle, videoKey));


            }
            Toast.makeText(getContext(), "Successfully parsed Video Data" + itemTrailerList.size(), Toast.LENGTH_SHORT).show();

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "can't parse the video data", Toast.LENGTH_SHORT).show();

        } finally {
            adapterTrailer.addAll(itemTrailerList);
            adapterTrailer.notifyDataSetChanged();
            trailersList.setAdapter(adapterTrailer);
            return itemTrailerList;
        }

    }
}
