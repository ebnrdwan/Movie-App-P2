package com.example.android.movies;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Abdulrhman on 20/10/2016.
 */
public class adapterMovie extends ArrayAdapter {
    String title;
    String overview;
    String releaseDate;
    double rate;
    String storedPoster;

    public adapterMovie(Context context, List<ItemsClass> itemsArraylist) {
        super(context, 0, itemsArraylist);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View rootview = convertView;
        if (rootview == null) {
            rootview = LayoutInflater.from(getContext()).inflate(R.layout.item_layout, parent, false);
        }
        ItemsClass currentItem = (ItemsClass) getItem(position);
        ImageView poster = (ImageView) rootview.findViewById(R.id.posterItem);
        if (isConnected()) {
            try {
                Picasso.with(getContext()).load(currentItem.getPoster()).into(poster);
                title = currentItem.getTitle();
                overview = currentItem.getOverview();
                releaseDate = currentItem.getReleaseDate();
                rate = currentItem.getrating();
            } catch (Exception e) {
//                Toast.makeText(getContext(), "can't load the image of the trailer", Toast.LENGTH_LONG).show();
            }
        } else {
            SharedPreferences mypreference = getContext().getSharedPreferences("moviepref", Context.MODE_PRIVATE);
            String storedPoster = mypreference.getString("storedPoster", "");

            Bitmap image = decodeBase64(currentItem.getPoster());
            poster.setImageBitmap(image);
        }

        Log.d("abdo", title + " \n" + overview + " \n" + releaseDate + " \n" + rate);

        return rootview;
    }

    public static void setPoster() {
    }

    public boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    public static Bitmap decodeBase64(String input) {
        byte[] decodedByte = Base64.decode(input, 0);
        return BitmapFactory
                .decodeByteArray(decodedByte, 0, decodedByte.length);
    }
}
