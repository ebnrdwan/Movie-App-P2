package com.example.android.movies;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.content.AsyncTaskLoader;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Abdulrhman on 20/10/2016.
 */
public class LoaderMovie extends AsyncTaskLoader<List<ItemsClass>> {
    String url;
    int id = Detail_fragment.id;


    public LoaderMovie(Context context, String url) {

        super(context);
        this.url = url;
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
        Log.d("LOG_TAG_CORRECT", " onStartLoading called");
    }

    @Override
    public List<ItemsClass> loadInBackground() {
        String title;
        String overview;
        String releaseDate;
        double rate;
        String storedPoster;
        List<ItemsClass> movieList;
        if (isConnected()){   if (url == null) {
            return null;
        }
            movieList = NetworkingMovie.FetchData(url);
            return movieList;
        }
        else {
            movieList=OFFLINELIST();
            return movieList;
        }


    }

    public boolean isConnected() {

        ConnectivityManager connectivityManager = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        } else {
            return false;
        }
    }
    public List<ItemsClass> OFFLINELIST(){



        SharedPreferences mypreference =   getContext().getSharedPreferences("moviepref", Context.MODE_PRIVATE);
//        String storedPoster = mypreference.getString("storedPoster", "");
//        String title = mypreference.getString("storedTitle", "");
//        String overview = mypreference.getString("storedOverview", "");
//        String releaseDate = mypreference.getString("storedDate", "");
//        float rate = mypreference.getFloat("storedrating", .0f);
//        int id = mypreference.getInt("id",0);
        String storedJsonList = mypreference.getString("storedjsonList","");
        Gson gson = new Gson();
        Type type = new TypeToken<ArrayList<ItemsClass>>() {}.getType();

//        ItemsClass itemsClassObject = new ItemsClass(storedPoster, title, releaseDate, overview, rate,id);
        List<ItemsClass> movieArrayList = new ArrayList<ItemsClass>();
        movieArrayList = gson.fromJson(storedJsonList,type);
        movieArrayList.size();
//        Toast.makeText(getContext(),"you have retreived list of"+ movieArrayList.size(),Toast.LENGTH_SHORT).show();
//        movieArrayList.add(itemsClassObject);
//        Toast.makeText(getContext(), "can't load the image of the trailer", Toast.LENGTH_LONG).show();
        return movieArrayList;
    }

}





